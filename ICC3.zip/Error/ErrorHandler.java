package Error;

public class ErrorHandler {
    private String errorMessage;

    public ErrorHandler(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}

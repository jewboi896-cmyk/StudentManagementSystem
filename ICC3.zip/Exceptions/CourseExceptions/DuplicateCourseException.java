package Exceptions.CourseExceptions;

public class DuplicateCourseException extends Exception {
    public DuplicateCourseException(String courseName) {
        super("Error: Course " + courseName + " is already in use");
    }
}

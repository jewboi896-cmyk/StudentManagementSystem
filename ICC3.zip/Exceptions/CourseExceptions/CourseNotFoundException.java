package Exceptions.CourseExceptions;

public class CourseNotFoundException extends Exception {
    CourseNotFoundException(String courseName) {
        super("Error: Course " + courseName + " not found");
    }
}

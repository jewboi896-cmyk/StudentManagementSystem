package Exceptions.CourseExceptions;

public class InvalidCourseDataException extends Exception {
    public InvalidCourseDataException(String courseName) {
        super("Error: Course " + courseName + " is invalid");
    }
}

package Exceptions.StudentExceptions;

public class StudentDataCorruptedException extends RuntimeException {
    public StudentDataCorruptedException(String message) {
        super(message);
    }
}

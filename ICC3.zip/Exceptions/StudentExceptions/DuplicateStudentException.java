package Exceptions.StudentExceptions;

public class DuplicateStudentException extends Exception {
    public DuplicateStudentException(String studentName) {
        super("Error: Student " + studentName + " already exists");
    }
}

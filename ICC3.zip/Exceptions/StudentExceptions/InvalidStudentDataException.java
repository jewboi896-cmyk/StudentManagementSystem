package Exceptions.StudentExceptions;

public class InvalidStudentDataException extends Exception {
    public InvalidStudentDataException(String studentName) {
        super("Error: Student " + studentName + " is invalid");
    }
}

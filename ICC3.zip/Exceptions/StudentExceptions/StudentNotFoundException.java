package Exceptions.StudentExceptions;

public class StudentNotFoundException extends Exception {
    public StudentNotFoundException(String studentName) {
        super("Error: Student not found with name " + studentName);
    }
}
